"use client";

import { motion } from "framer-motion";

export default function Story() {
  return (
    <section className="va-story">
      <div className="va-container">
        <div className="va-story-content">
          <motion.div
            className="va-story-text"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="va-section-title">كيف بدأت رحلتنا</h2>
            <p className="va-story-description">
              تأسست <span>Velante</span> في عام 2025، من خلال شغف مشترك لسد
              الفجوة بين الإبداع البصري والوظائف الرقمية. لاحظنا أن الكثير من
              الشركات الناشئة والمنشآت الصغيرة تبحث عن حلول متكاملة ولكنها تواجه
              عروضًا مبعثرة أو مكلفة. ومن هنا، ولدت فكرة <span>Velante</span> أن
              نكون الوجهة الواحدة التي توفر حلولاً بصرية رقمية متكاملة، بجودة
              استثنائية وأسعار شفافة.
            </p>
          </motion.div>
          <motion.div
            className="va-story-image"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <img
              src="/images/fullLogo.webp"
              alt="مؤسسو velante"
              className="va-story-img"
              onError={(e) => (e.target.src = "/images/logo.webp")}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
