# إعداد Vercel Postgres - دليل شامل

## 🎯 لماذا Vercel Postgres؟

- ✅ **لا يتوقف أبداً** (مش مثل Supabase)
- ✅ **تكامل مثالي** مع Vercel
- ✅ **أداء أسرع** (نفس الشبكة)
- ✅ **مجاني لحد 1GB**
- ✅ **إدارة سهلة** من لوحة Vercel

## 🚀 الخطوات العملية:

### 1. إنشاء قاعدة البيانات في Vercel

1. اذهب إلى [vercel.com](https://vercel.com)
2. سجل دخول بحسابك
3. اضغط على مشروعك **velante**
4. اذهب إلى تبويب **"Storage"**
5. اضغط **"Create Database"**
6. اختر **"Postgres"**
7. اكتب اسم قاعدة البيانات: `velante-db`
8. اختر المنطقة: `Dubai` (الأقرب للشرق الأوسط)
9. اضغط **"Create"**

### 2. الحصول على رابط الاتصال

1. بعد إنشاء قاعدة البيانات، اضغط عليها
2. اذهب إلى تبويب **"Settings"**
3. انسخ **"Connection String"**
4. سيبدو هكذا:
```
postgresql://default:password@ep-xxx-xxx.us-east-1.postgres.vercel-storage.com:5432/verceldb
```

### 3. إضافة متغيرات البيئة

1. في مشروعك على Vercel، اذهب إلى **"Settings"**
2. اضغط **"Environment Variables"**
3. أضف متغير جديد:
   - **Name**: `DATABASE_URL`
   - **Value**: رابط الاتصال الذي نسخته
   - **Environments**: Production, Preview, Development
4. اضغط **"Save"**

### 4. إضافة المتغير محلياً

أنشئ ملف `.env.local` في مشروعك:
```bash
DATABASE_URL="postgresql://default:password@ep-xxx-xxx.us-east-1.postgres.vercel-storage.com:5432/verceldb"
```

## 🔧 إعداد المشروع:

### 1. تحديث Prisma Schema

تأكد من أن `prisma/schema.prisma` يحتوي على:
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

### 2. تشغيل قاعدة البيانات

```bash
# إنشاء الجداول
npm run db:push

# إدخال البيانات الأولية
npm run db:seed

# فتح واجهة الإدارة
npm run db:studio
```

### 3. تحديث Vercel Configuration

تأكد من أن `vercel.json` يحتوي على:
```json
{
  "env": {
    "DATABASE_URL": "@database_url"
  },
  "build": {
    "env": {
      "DATABASE_URL": "@database_url"
    }
  }
}
```

## 🚀 نشر المشروع:

### 1. رفع التغييرات
```bash
git add .
git commit -m "Add Vercel Postgres database"
git push origin main
```

### 2. Vercel سيقوم تلقائياً بـ:
- بناء المشروع
- ربط قاعدة البيانات
- تشغيل migrations
- نشر المشروع

## 📊 مراقبة قاعدة البيانات:

### في Vercel Dashboard:
1. اذهب لمشروعك
2. اضغط على قاعدة البيانات
3. شاهد الإحصائيات والاستعلامات
4. أضف/عدل/احذف البيانات

### في Prisma Studio:
```bash
npm run db:studio
```
- واجهة رسومية جميلة
- إدارة كاملة للبيانات
- تشغيل استعلامات

## 🔒 الأمان:

### 1. حماية كلمة المرور:
- لا تضع `DATABASE_URL` في الكود
- استخدم Environment Variables فقط
- أضف `.env.local` لـ `.gitignore`

### 2. نسخ احتياطية:
```bash
# تصدير البيانات
pg_dump $DATABASE_URL > backup.sql

# استيراد البيانات
psql $DATABASE_URL < backup.sql
```

## 💰 التكلفة:

### **المجاني:**
- **1GB** مساحة تخزين
- **1000** استعلام في الساعة
- **100MB** نقل بيانات شهرياً

### **المدفوع:**
- **$20/شهر** للخطة Pro
- **10GB** مساحة تخزين
- **استعلامات غير محدودة**
- **1GB** نقل بيانات شهرياً

## 🆘 حل المشاكل:

### مشكلة الاتصال:
```bash
# تأكد من صحة الرابط
echo $DATABASE_URL

# اختبر الاتصال
npm run db:studio
```

### مشكلة SSL:
```bash
# أضف ?sslmode=require للرابط
DATABASE_URL="postgresql://user:pass@host:5432/db?sslmode=require"
```

### مشكلة Timeout:
```bash
# أضف timeout settings
DATABASE_URL="postgresql://user:pass@host:5432/db?connect_timeout=60"
```

## 🎯 المميزات الإضافية:

### 1. **Branching** (للاختبار):
- أنشئ branch جديد
- Vercel ينشئ قاعدة بيانات منفصلة تلقائياً
- اختبر التغييرات بأمان

### 2. **Backups** التلقائية:
- Vercel يحفظ نسخ احتياطية تلقائياً
- استرجع البيانات من أي وقت

### 3. **Monitoring**:
- مراقبة الأداء
- إحصائيات الاستعلامات
- تنبيهات عند المشاكل

## 🚀 الخطوات التالية:

1. **أنشئ قاعدة البيانات** على Vercel
2. **أضف Environment Variables**
3. **شغل `npm run db:push`**
4. **شغل `npm run db:seed`**
5. **ارفع المشروع** على Vercel
6. **استمتع بقاعدة بيانات مستقرة!** 🎉
