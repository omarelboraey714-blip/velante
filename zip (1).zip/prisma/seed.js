const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting the seeding process...');

  // 1. Clear existing data in the correct order to avoid foreign key constraints
  console.log('🗑️ Deleting existing data...');
  await prisma.testimonial.deleteMany({});
  await prisma.project.deleteMany({});
  await prisma.client.deleteMany({});
  await prisma.fAQ.deleteMany({});
  await prisma.newsletterSubscription.deleteMany({});
  await prisma.package.deleteMany({});
  await prisma.service.deleteMany({});
  await prisma.stat.deleteMany({});
  await prisma.teamMember.deleteMany({});
  await prisma.value.deleteMany({});
  await prisma.contact.deleteMany({});
  console.log('✅ Existing data deleted.');

  // 2. Seed Clients
  const clientsData = [
    { id: '203a3a2e-a628-46b6-b3e3-6824348d0ddc', name: 'أحمد محمد', country: 'مصر', flag: '🇪🇬', avatar: '/images/avatar1.png' },
    { id: '0adc3429-f259-467d-84e4-778df6440729', name: 'فاطمة العلي', country: 'السعودية', flag: '🇸🇦', avatar: '/images/avatar2.png' },
    { id: '936b5c67-e808-4394-b454-0df389134a1b', name: 'محمد عبدالله', country: 'الإمارات', flag: '🇦🇪', avatar: '/images/avatar3.png' },
    { id: '0a134075-4bef-405b-b642-aa363d5b19cf', name: 'سارة حسن', country: 'مصر', flag: '🇪🇬', avatar: '/images/avatar4.png' },
  ];
  await prisma.client.createMany({ data: clientsData });
  console.log(`✅ ${clientsData.length} Clients seeded.`);

  // 3. Seed Projects with detailed JSON fields
  const projectsData = [
    {
      id: 'd9f8c7b6-a5d4-4f3e-8b1a-2c9d8e7f6a5b',
      title: 'هوية بصرية لمتجر "تميز"',
      category: 'branding',
      image: '/images/featured/1.png',
      thumbnail: '/images/thumbs/1.png',
      badge: 'الأكثر مشاهدة',
      liveUrl: '#',
      description: 'إعادة تصميم الهوية البصرية لمتجر "تميز" لتعكس الجودة والفخامة، مع التركيز على تجربة مستخدم موحدة عبر جميع المنصات.',
      featured: true,
      tag: 'branding',
      images: [
        '/images/gallery/1.png',
        '/images/gallery/2.png',
        '/images/gallery/3.png',
      ],
      challenge: {
        description: 'كان التحدي هو إنشاء هوية بصرية عصرية ومميزة يمكنها المنافسة في سوق مزدحم، مع الحفاظ على روح العلامة التجارية الأصلية.',
        points: [
            "شعار وهوية بصرية قديمة لا تجذب الجمهور المستهدف.",
            "عدم وجود استراتيجية واضحة لوسائل التواصل الاجتماعي.",
          ],
      },
      solution: {
        description: 'قمنا بتطوير شعار جديد، ونظام ألوان وخطوط حديث، بالإضافة إلى مجموعة من القوالب والتصاميم التي يمكن استخدامها في التسويق والمواد المطبوعة.',
        points: [
            "هوية بصرية جديدة وشعار يجمع بين العناصر اليابانية التقليدية والخطوط العصرية.",
            "حملة سوشيال ميديا متكاملة.",
        ],
        quote: "ركزنا على خلق تجربة بصرية متكاملة تبدأ من الشعار وتنتهي عند تفاعل العميل مع الموقع.",
      },
      results: [
        { "number": "30%", "label": "زيادة في التفاعل على وسائل التواصل الاجتماعي", "icon": "❤️" },
        { "number": "50%", "label": "تحسين التعرف على العلامة التجارية", "icon": "📈" },
      ],
      tools: [
        { "name": "Adobe Illustrator", "icon": "✏️" },
        { "name": "Adobe Photoshop", "icon": "🖼️" },
        { "name": "Figma", "icon": "🎨" },
      ],
      clientInfo: {
        name: clientsData[0].name,
        service: 'هوية بصرية',
        year: '2023',
        field: "متجر إلكتروني متخصص في المنتجات الفاخرة.",
        vision: "أن يصبح الوجهة الأولى للمنتجات عالية الجودة في المنطقة.",
        targetAudience: "العملاء الباحثون عن الجودة والتميز.",
      },
    },
    {
      id: 'e1a2b3c4-d5e6-4f7g-8h9i-j0k1l2m3n4o5',
      title: 'تطوير متجر "أناقة" الإلكتروني',
      category: 'web-development',
      image: '/images/featured/2.png',
      thumbnail: '/images/thumbs/2.png',
      badge: 'جديد',
      liveUrl: '#',
      description: 'تطوير متجر إلكتروني متكامل لعلامة "أناقة" التجارية، مع التركيز على تجربة مستخدم سلسة وسرعة التحميل.',
      featured: true,
      tag: 'web-development',
      images: [
        '/images/gallery/4.png',
        '/images/gallery/5.png',
        '/images/gallery/6.png',
      ],
      challenge: {
        description: 'بناء متجر إلكتروني قادر على التعامل مع عدد كبير من المنتجات والزوار، مع توفير تجربة شراء سهلة وآمنة.',
        points: [
          "موقع إلكتروني بطيء وغير متوافق مع الجوال.",
          "ضعف التواجد الرقمي أمام المنافسة القوية."
        ],
      },
      solution: {
        description: 'استخدمنا منصة Next.js لبناء واجهة أمامية سريعة وتفاعلية، مع ربطها بنظام إدارة محتوى سهل الاستخدام لفريق عمل "أناقة".',
        points: [
          "موقع ويب تفاعلي مبني بـ Next.js.",
          "نظام دفع آمن متكامل.",
        ],
        quote: "السرعة والأمان كانا أولويتنا لضمان أفضل تجربة تسوق.",
      },
      results: [
        { "number": "40%", "label": "زيادة المبيعات خلال أول 3 أشهر", "icon": "📈" },
        { "number": "25%", "label": "تقليل معدل الارتداد", "icon": "👁️" },
      ],
      tools: [
        { "name": "Next.js", "icon": "⚡" },
        { "name": "React", "icon": "⚛️" },
        { "name": "Prisma", "icon": "🗃️" },
        { "name": "Stripe", "icon": "💳" },
      ],
      clientInfo: {
        name: clientsData[1].name,
        service: 'تطوير متجر إلكتروني',
        year: '2024',
        field: "علامة تجارية متخصصة في الأزياء العصرية.",
        vision: "تقديم أحدث صيحات الموضة بأسعار معقولة.",
        targetAudience: "الشباب والفتيات المهتمون بالموضة.",
      },
    },
  ];
  for (const project of projectsData) {
    await prisma.project.create({ data: project });
  }
  console.log(`✅ ${projectsData.length} Projects seeded.`);

  // 4. Seed Testimonials and link them to clients and projects
  const testimonialsData = [
    { rating: 5, text: 'فريق مبدع ومحترف، لقد نقلوا علامتنا التجارية إلى مستوى جديد تمامًا. سعداء جدًا بالنتيجة!', clientId: clientsData[0].id, projectId: projectsData[0].id, category: 'branding' },
    { rating: 5, text: 'المتجر الإلكتروني الجديد فاق توقعاتنا. التصميم رائع والأداء سريع جدًا. شكرًا لفريق العمل.', clientId: clientsData[1].id, projectId: projectsData[1].id, category: 'web-development' },
    { rating: 4, text: 'تجربة عمل ممتازة، تواصل مستمر واهتمام بأدق التفاصيل. أنصح بالتعامل معهم.', clientId: clientsData[2].id, category: 'ads' },
  ];
  await prisma.testimonial.createMany({ data: testimonialsData });
  console.log(`✅ ${testimonialsData.length} Testimonials seeded.`);
  
  // 5. Seed other models
  const faqsData = [
    { id: '19cb741d-3aa2-486e-bb6c-331a82ff32e0', question: 'ماذا لو لم يعجبني التصميم الأولي؟', answer: 'نعمل على التعديل حتى تحقيق رضاك', category: 'branding' },
    { id: '21e9bf73-5c43-4e00-bbb7-4f6b9f65a1c8', question: 'هل يمكنني استخدام الشعار على جميع المنصات؟', answer: 'نعم، نسقنا لك جميع الصيغ', category: 'branding' },
    { id: '02e92fb7-7440-48c1-b8aa-42af3b7872e2', question: 'كم تستغرق مدة تصميم الموقع؟', answer: '2-4 أسابيع حسب التعقيد', category: 'web-development' },
    { id: '367d02ed-6bfe-4733-8107-c4ddcdc93501', question: 'ما هي ضمانات الاستمرارية بعد التسليم؟', answer: 'دعم فني لمدة 3 أشهر', category: 'web-development' },
    { id: '54aa2efc-4970-415c-b253-76bf4f2a6f77', question: 'كيف تقيسون نجاح الحملة؟', answer: 'بمؤشرات مثل ROAS، تكلفة التحويل، معدل النقر', category: 'ads' },
    { id: 'da53fc32-e006-4aa3-8bee-8f7dfc698ae6', question: 'كم الميزانية المناسبة للبدء؟', answer: 'ننصح بـ 3,000 جنيه للبدء بشكل فعال', category: 'ads' },
    { id: '1198c659-cfbe-4a99-b2f7-c9496aa92b14', question: 'ما هي طرق الدفع المتاحة؟', answer: 'الدفع نقدًا، تحويل بنكي، أو عبر Paymob (بطاقات ائتمان/خصم) في مصر. وفي السعودية تحويل بنكي أو عبر PayPal.', category: 'packages' },
    { id: '99824de7-9392-49b7-84cd-0b8102dff072', question: 'هل يمكنني تخصيص الباقة؟', answer: 'بالتأكيد! جميع الباقات قابلة للتخصيص. اختر الباقة الأقرب لاحتياجك وأخبرنا بما تريد إضافته أو إزالته وسنعدل السعر بناءً عليه.', category: 'packages' },
    { id: '323a852e-d52c-40d3-b3a5-c39e17c9b1e1', question: 'ما المعلومات التي يجب أن أقدمها عند التواصل؟', answer: 'يُفضل أن تخبرنا بنبذة عن مشروعك، أهدافك، الجمهور المستهدف، والموعد النهائي الذي تطمح إليه. كلما زادت التفاصيل، استطعنا مساعدتك بشكل أفضل.', category: 'contact' },
    { id: '53c3c027-db55-4307-ad7b-ce56e2ee9b87', question: 'ما هي مدة الرد على استفساري؟', answer: 'نرد على جميع الاستفسارات عبر البريد والهاتف خلال 24 ساعة خلال أيام العمل (من الأحد إلى الخميس).', category: 'contact' },
  ];
  await prisma.fAQ.createMany({ data: faqsData });
  console.log(`✅ ${faqsData.length} FAQs seeded.`);

  const packagesData = [
    { id: '5e82c2fb-ace3-491e-ba98-a032ae989105', category: 'branding', title: 'باقة البداية', priceMin: 2500, priceMax: 4500, currency: 'EGP', isMonthly: false, description: 'هوية بسيطة للشركات الناشئة', features: ['تصميم شعار احترافي', 'دليل ألوان وخطوط', 'تصميم بطاقة عمل'], popular: false },
    { id: '6b01ddbf-6755-4033-835d-2ec1a50448f3', category: 'branding', title: 'باقة البصمة', priceMin: 12000, priceMax: 20000, currency: 'EGP', isMonthly: false, description: 'هوية شاملة واحترافية', features: ['كتيب دليل الهوية', 'ستايل فوتوجرافي وموكابس', 'قوالب وسائط اجتماعية'], popular: true },
    { id: '9d517e58-8f42-4000-ade2-59daa1f5ec27', category: 'web', title: 'باقة الانطلاقة', priceMin: 5000, priceMax: 8000, currency: 'EGP', isMonthly: false, description: 'موقع تعريفي بسيط للظهور الإلكتروني السريع', features: ['لاندينج بيج أو ٣ صفحات أساسية', 'تصميم سريع وخفيف', 'عرض واضح للخدمات'], popular: false },
    { id: '1a6c555e-d56a-4698-8bd6-102243eccb07', category: 'web', title: 'باقة النمو', priceMin: 10000, priceMax: 18000, currency: 'EGP', isMonthly: false, description: 'موقع متعدد الصفحات للشركات في مرحلة التوسع', features: ['تصميم متجاوب', 'لوحة تحكم أساسية', 'تحسين مبدئي لمحركات البحث'], popular: true },
    { id: '294fccfc-f33b-4704-8b17-324d6492bdc5', category: 'ads', title: 'باقة التجربة', priceMin: 4000, priceMax: 7000, currency: 'EGP', isMonthly: false, description: 'إعلانات قصيرة المدى لاختبار الاستهداف', features: ['تحليل النتائج', 'تقارير أداء مفصلة'], popular: false },
    { id: '499d8519-c421-4c3b-bde0-2733766e4073', category: 'ads', title: 'باقة السيطرة', priceMin: 20000, priceMax: 35000, currency: 'EGP', isMonthly: false, description: 'إدارة حملات متعددة وتحسين ROI', features: ['مسار تحويل كامل', 'تحليلات متقدمة', 'تحسين مستمر للأداء'], popular: true },
  ];
  await prisma.package.createMany({ data: packagesData });
  console.log(`✅ ${packagesData.length} Packages seeded.`);

  const servicesData = [
    { id: '9f2b9c03-e9d9-4ee4-8e0b-931e04b5d74d', title: 'تصميم شعار نصي (Wordmark)', description: 'شعار نصي أنيق يعكس اسم مشروعك بلمسة عصرية مدروسة.', price: '1,500 ج.م', category: 'branding' },
    { id: 'f6afd3b7-ed36-410a-b222-f70553647ea5', title: 'تصميم Landing Page', description: 'صفحة هبوط مصممة خصيصًا لحملاتك الإعلانية بهدف تحويل الزوار إلى عملاء مباشرة.', price: '3,000 – 5,000 ج.م', category: 'web-development' },
    { id: '17aee520-8398-48ac-81fb-f5ebac5c79bc', title: 'إعداد الحملات', description: 'تصميم حملات إعلانية احترافية تحقق أفضل توازن بين الوصول والتكلفة، مع إعداد متكامل للأهداف.', price: '1,500 ج.م', category: 'ads' },
    { id: '2d7be060-fa45-493d-9b30-68a93ed6e9fa', title: 'إعداد خطة محتوى (Content Calendar)', description: 'خطة محتوى استراتيجية تضمن حضورك المستمر، مرتبطة بالمواسم والعروض، وتبني علاقة دائمة مع الجمهور.', price: '1,500 ج.م / شهري', category: 'social-media' },
  ];
  await prisma.service.createMany({ data: servicesData });
  console.log(`✅ ${servicesData.length} Services seeded.`);

  const statsData = [
    { id: 'da0caec7-c2d8-4b6d-a98c-201e05e8e295', number: 50, label: 'مشروع مكتمل', suffix: '+' },
    { id: '7a1ee776-9a47-4e2a-be56-7043ac4e1523', number: 30, label: 'عميل سعيد', suffix: '+' },
    { id: 'ed337807-1d0c-4f7d-9903-fa8c1a7db09b', number: 98, label: 'معدل رضا العملاء', suffix: '%' },
    { id: 'e6a18925-2796-4584-880f-2aa13304358d', number: 2, label: 'سنوات من الإبداع', suffix: '+' },
  ];
  await prisma.stat.createMany({ data: statsData });
  console.log(`✅ ${statsData.length} Stats seeded.`);

  const teamMembersData = [
    { id: 'd8d8bd79-46c9-4210-823a-2e77c3bc68df', name: 'عمر البرعى', position: 'المؤسس والمدير التنفيذي', description: 'شغوف بتحويل الأفكار المجردة إلى علامات تجارية ناجحة ومؤثرة.', image: '/images/team1.jpg', social: { "behance": "#", "linkedin": "#" } },
    { id: 'dde69bcc-59da-4471-b420-2812bb73e5c1', name: 'نور محمود', position: 'مصممة جرافيك أول', description: 'تعشق تحويل الأفكار المجردة إلى هويات بصرية تحكي قصة.', image: '/images/team2.jpg', social: { "behance": "#", "linkedin": "#" } },
    { id: 'e3f65e7a-a221-4dab-ac42-e8a2a33b6d1a', name: 'محمد عماد', position: 'مطور ويب full-stack', description: 'متخصص في بناء مواقع وتطبيقات ويب سريعة وآمنة وفعالة.', image: '/images/team3.jpg', social: { "github": "#", "linkedin": "#" } },
    { id: '9a05ca94-63bd-4283-9903-5899c385f379', name: 'هند خالد', position: 'أخصائية تسويق إلكتروني', description: 'خبيرة في إدارة الحملات الإعلانية وتحقيق أعلى عائد على الاستثمار.', image: '/images/team4.jpg', social: { "twitter": "#", "linkedin": "#" } },
  ];
  await prisma.teamMember.createMany({ data: teamMembersData });
  console.log(`✅ ${teamMembersData.length} Team Members seeded.`);

  const valuesData = [
    { id: '62b310bd-a2f5-4b52-9619-9780e704a23a', icon: '✨', title: 'الإبداع', description: 'نبتكر حلولاً خارج الصندوق تجعل علامتك التجارية تتألق وتبقى عالقة في الأذهان.' },
    { id: '27bf5b53-22ba-4c3f-ae82-ff518ca7deda', icon: '✅', title: 'الجودة', description: 'لا نقدم إلا الأفضل. نهتم بأدق التفاصيل لضمان نتائج نهائية خالية من العيوب.' },
    { id: '97c7eb91-b69a-4ef6-b766-dfa2aaeaa247', icon: '🔍', title: 'الشفافية', description: 'أسعار واضحة، تواصل مفتوح، وجداول زمنية واقعية. لا مفاجآت.' },
    { id: 'b37933d0-6162-4b59-bff9-26360fa701b8', icon: '🤝', title: 'الشراكة', description: 'نجاحك هو نجاحنا. نعمل كجزء من فريقك لتحقيق أهدافك.' },
  ];
  await prisma.value.createMany({ data: valuesData });
  console.log(`✅ ${valuesData.length} Values seeded.`);

  console.log('🎉 Seeding finished successfully!');
}

main()
  .catch((e) => {
    console.error('An error occurred during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
