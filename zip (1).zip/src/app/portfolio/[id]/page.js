"use client";

import { useParams } from "next/navigation";
import useSWR from "swr";
import Header from "@/components/project/Header";
import Client from "@/components/project/Client";
import Challenge from "@/components/project/Challenge";
import Solution from "@/components/project/Solution";
import Tools from "@/components/project/Tools";
import Results from "@/components/project/Results";
import CTA from "@/components/project/CTA";
import Navigation from "@/components/project/Navigation";
import Share from "@/components/project/Share";
import Lightbox from "@/components/project/Lightbox";
import "./ProjectPage.css";

const fetcher = (url) => fetch(url).then((res) => res.json());

export default function ProjectPage() {
  const { id } = useParams();
  const {
    data: project,
    error,
    isLoading,
  } = useSWR(id ? `/api/projects/${id}` : null, fetcher);

  if (isLoading) {
    return (
      <div className="vp-page" dir="rtl">
        <div className="vp-container text-center py-16">
          <p className="text-lg text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (error || !project || project.error) {
    return (
      <div className="vp-page" dir="rtl">
        <div className="vp-container text-center py-16">
          <p className="text-lg text-red-600">
            {project?.error || "لم يتم العثور على المشروع"}
          </p>
          <a
            href="/portfolio"
            className="vp-btn vp-btn--primary mt-4 inline-block"
          >
            العودة إلى معرض الأعمال
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="vp-page" dir="rtl">
      <Header project={project} />
      <Client project={project} />
      <Challenge project={project} />
      <Solution project={project} />
      <Lightbox project={project} />
      <Tools project={project} />
      <Results project={project} />
      <CTA />
      <Navigation project={project} />
      <Share project={project} />
    </div>
  );
}